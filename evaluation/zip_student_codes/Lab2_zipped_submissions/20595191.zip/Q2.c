#include<stdio.h>
int main(){
    float m1,m2,m3;
    char n1,n2,n3;
    printf("enter name of student 1: ");
    scanf("%s", &n1);
    printf("enter the mark for student 1: ");
    scanf("%f", &m1);
    printf("enter name of student 1: ");
    scanf("%s", &n2);
    printf("enter the mark for student 1: ");
    scanf("%f", &m2);
    printf("enter name of student 1: ");
    scanf("%s", &n3);
    printf("enter the mark for student 1: ");
    scanf("%f", &m3);
    printf("students names and marks:\n");
    printf("%s : %f", n1,m1);
    printf("%s : %f", n2,m2);
    printf("%s : %f", n3,m3);
}