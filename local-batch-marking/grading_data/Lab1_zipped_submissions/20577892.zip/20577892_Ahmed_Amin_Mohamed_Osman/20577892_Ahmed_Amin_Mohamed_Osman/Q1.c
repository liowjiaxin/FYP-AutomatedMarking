#include <stdio.h>

int main() {
    int rows;
    int columns;

    printf("Enter the number of rows: ");
    scanf("%d", &rows);
    printf("Enter the number of columns: ");
    scanf("%d", &columns);

    for (int j = 0; i < columns; i++) {
        for (i=0; i<width;i++)
            printf("*");
        printf("\n");
    }

    return 0;
}